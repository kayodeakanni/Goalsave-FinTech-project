const Joi = require('joi');

// Schema used when creating a new note — title and content are mandatory
const createNoteSchema = Joi.object({
  title: Joi.string().trim().min(1).max(200).required().messages({
    'string.empty': 'Title cannot be empty',
    'string.max': 'Title cannot exceed 200 characters',
    'any.required': 'Title is required',
  }),
  content: Joi.string().trim().min(1).required().messages({
    'string.empty': 'Content cannot be empty',
    'any.required': 'Content is required',
  }),
  category: Joi.string().trim().max(100).messages({
    'string.max': 'Category cannot exceed 100 characters',
  }),
  tags: Joi.array().items(Joi.string().trim().max(50)).messages({
    'array.base': 'Tags must be an array of strings',
  }),
});

// Schema used when updating a note — every field is optional but at least one must be present
const updateNoteSchema = Joi.object({
  title: Joi.string().trim().min(1).max(200).messages({
    'string.empty': 'Title cannot be empty',
    'string.max': 'Title cannot exceed 200 characters',
  }),
  content: Joi.string().trim().min(1).messages({
    'string.empty': 'Content cannot be empty',
  }),
  category: Joi.string().trim().max(100).messages({
    'string.max': 'Category cannot exceed 100 characters',
  }),
  tags: Joi.array().items(Joi.string().trim().max(50)).messages({
    'array.base': 'Tags must be an array of strings',
  }),
})
  .min(1)
  .messages({
    'object.min': 'At least one field (title, content, category, tags) must be provided to update',
  });

/**
 * Validates the payload for note creation.
 * @param {Object} data - raw request body
 * @returns {Joi.ValidationResult}
 */
const validateCreateNote = (data) => createNoteSchema.validate(data, { abortEarly: false, stripUnknown: true });

/**
 * Validates the payload for note updates.
 * @param {Object} data - raw request body
 * @returns {Joi.ValidationResult}
 */
const validateUpdateNote = (data) => updateNoteSchema.validate(data, { abortEarly: false, stripUnknown: true });

module.exports = {
  validateCreateNote,
  validateUpdateNote,
};