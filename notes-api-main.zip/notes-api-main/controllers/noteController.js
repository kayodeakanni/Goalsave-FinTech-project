const mongoose = require('mongoose');
const Note = require('../models/Note');
const { validateCreateNote, validateUpdateNote } = require('../validators/noteValidator');

/**
 * Wraps an async route handler so any rejected promise / thrown error
 * is automatically forwarded to Express's error-handling middleware,
 * avoiding repetitive try/catch blocks in every controller function.
 */
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/**
 * Converts a query string like "title" or "-createdAt" or "title,-createdAt"
 * into a Mongoose-compatible sort object, e.g. { title: 1 } or { createdAt: -1 }.
 */
const parseSortParam = (sortParam) => {
  const sortObj = {};

  sortParam
    .split(',')
    .map((field) => field.trim())
    .filter(Boolean)
    .forEach((field) => {
      if (field.startsWith('-')) {
        sortObj[field.substring(1)] = -1;
      } else {
        sortObj[field] = 1;
      }
    });

  return sortObj;
};

// @desc    Create a new note
// @route   POST /api/notes
// @access  Public
const createNote = asyncHandler(async (req, res) => {
  const { error, value } = validateCreateNote(req.body);

  if (error) {
    const message = error.details.map((d) => d.message).join(', ');
    return res.status(400).json({ success: false, message });
  }

  const note = await Note.create(value);

  res.status(201).json({
    success: true,
    data: note,
  });
});

// @desc    Get all notes — supports pagination, sorting, text search, and category filtering
// @route   GET /api/notes
// @query   page, limit, sort, search|q, category
// @access  Public
const getNotes = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.max(parseInt(req.query.limit, 10) || 10, 1);
  const skip = (page - 1) * limit;

  const searchTerm = req.query.search || req.query.q;
  const { category } = req.query;

  const filter = {};

  if (searchTerm) {
    filter.$text = { $search: searchTerm };
  }

  if (category) {
    // Case-insensitive exact match so "work" and "Work" both match the same category
    filter.category = { $regex: `^${category.trim()}$`, $options: 'i' };
  }

  let query = Note.find(filter);
  const countPromise = Note.countDocuments(filter);

  if (req.query.sort) {
    // Explicit sort always takes priority over relevance sorting
    query = query.sort(parseSortParam(req.query.sort));
  } else if (searchTerm) {
    // No explicit sort requested during a text search — rank by relevance
    query = query.select({ score: { $meta: 'textScore' } }).sort({ score: { $meta: 'textScore' } });
  } else {
    // Sensible default: newest notes first
    query = query.sort({ createdAt: -1 });
  }

  const [notes, total] = await Promise.all([query.skip(skip).limit(limit), countPromise]);

  res.status(200).json({
    success: true,
    count: notes.length,
    pagination: {
      total,
      page,
      limit,
      totalPages: Math.max(Math.ceil(total / limit), 1),
      hasNextPage: page * limit < total,
      hasPrevPage: page > 1,
    },
    data: notes,
  });
});

// @desc    Get a single note by its ID
// @route   GET /api/notes/:id
// @access  Public
const getNoteById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: `Invalid ID format: ${id}` });
  }

  const note = await Note.findById(id);

  if (!note) {
    return res.status(404).json({ success: false, message: `Note not found with id: ${id}` });
  }

  res.status(200).json({ success: true, data: note });
});

// @desc    Update an existing note
// @route   PUT /api/notes/:id
// @access  Public
const updateNote = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: `Invalid ID format: ${id}` });
  }

  const { error, value } = validateUpdateNote(req.body);

  if (error) {
    const message = error.details.map((d) => d.message).join(', ');
    return res.status(400).json({ success: false, message });
  }

  const note = await Note.findByIdAndUpdate(id, value, {
    new: true, // return the updated document
    runValidators: true, // re-run schema validators on update
  });

  if (!note) {
    return res.status(404).json({ success: false, message: `Note not found with id: ${id}` });
  }

  res.status(200).json({ success: true, data: note });
});

// @desc    Delete a note
// @route   DELETE /api/notes/:id
// @access  Public
const deleteNote = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: `Invalid ID format: ${id}` });
  }

  const note = await Note.findByIdAndDelete(id);

  if (!note) {
    return res.status(404).json({ success: false, message: `Note not found with id: ${id}` });
  }

  res.status(200).json({
    success: true,
    message: 'Note deleted successfully',
    data: note,
  });
});

module.exports = {
  createNote,
  getNotes,
  getNoteById,
  updateNote,
  deleteNote,
};