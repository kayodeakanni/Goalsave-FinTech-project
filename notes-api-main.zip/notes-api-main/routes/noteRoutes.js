const express = require('express');
const router = express.Router();

const {
  createNote,
  getNotes,
  getNoteById,
  updateNote,
  deleteNote,
} = require('../controllers/noteController');

// POST   /api/notes      -> createNote
// GET    /api/notes      -> getNotes (pagination, sorting, search, category filter)
router.route('/').post(createNote).get(getNotes);

// GET    /api/notes/:id  -> getNoteById
// PUT    /api/notes/:id  -> updateNote
// DELETE /api/notes/:id  -> deleteNote
router.route('/:id').get(getNoteById).put(updateNote).delete(deleteNote);

module.exports = router;