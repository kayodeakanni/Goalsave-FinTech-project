# Personal Knowledge Base / Notes API

A production-ready REST API for managing personal notes, built with Node.js, Express, and MongoDB (Mongoose). Supports full CRUD operations, pagination, sorting, full-text search, and category filtering.

## Features

- Full CRUD for notes (create, read, update, delete)
- Joi-based request validation with clear error messages
- MongoDB full-text search (weighted across `title` and `content`)
- Pagination (`page`, `limit`) with metadata in every list response
- Flexible multi-field sorting (`sort=title`, `sort=-createdAt`, `sort=category,-createdAt`)
- Category filtering, case-insensitive
- Centralized error handling with consistent JSON responses and correct HTTP status codes
- Clean MVC-style project structure

## Project Structure

```
├── config/
│   └── db.js                # MongoDB connection logic
├── controllers/
│   └── noteController.js    # CRUD + query logic (pagination, sort, search)
├── middleware/
│   └── errorHandler.js      # 404 + global error handler
├── models/
│   └── Note.js              # Mongoose schema with text indexes
├── routes/
│   └── noteRoutes.js        # Route definitions
├── validators/
│   └── noteValidator.js     # Joi validation schemas
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js                 # App entry point
```

## Prerequisites

- Node.js v18 or later
- A MongoDB instance — either a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster or a local MongoDB server

## Installation

1. Clone or download this repository, then move into the project folder:

   ```bash
   cd notes-api
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Create your environment file from the provided template:

   ```bash
   cp .env.example .env
   ```

4. Open `.env` and fill in your values:

   ```env
   PORT=5000
   NODE_ENV=development
   MONGO_URI=mongodb+srv://<username>:<password>@<cluster-url>/<db-name>?retryWrites=true&w=majority
   ```

   - For **MongoDB Atlas**: get this string from Atlas → Database → Connect → "Drivers", then swap in your database user's username/password.
   - For a **local MongoDB**: you can instead use something like `mongodb://127.0.0.1:27017/notes_db`.

## Running the API

Development (auto-restarts on file changes via nodemon):

```bash
npm run dev
```

Production:

```bash
npm start
```

On a successful start you should see:

```
MongoDB Connected: <your-cluster-host>
Server running in development mode on port 5000
```

The API will be available at `http://localhost:5000`.

## Data Model

| Field       | Type     | Required | Notes                                  |
|-------------|----------|----------|-----------------------------------------|
| `title`     | String   | Yes      | Max 200 chars, text-indexed             |
| `content`   | String   | Yes      | Text-indexed                            |
| `category`  | String   | No       | Defaults to `"General"`                |
| `tags`      | [String] | No       | Stored lowercase, trimmed               |
| `createdAt` | Date     | auto     | Set automatically by Mongoose timestamps |
| `updatedAt` | Date     | auto     | Set automatically by Mongoose timestamps |

## API Reference

All responses follow a consistent shape:

**Success:**
```json
{ "success": true, "data": { ... } }
```

**Error:**
```json
{ "success": false, "message": "Human-readable error description" }
```

---

### Create a note

`POST /api/notes`

```bash
curl -X POST http://localhost:5000/api/notes \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Mongoose Indexes",
    "content": "Text indexes allow MongoDB to perform efficient full-text search across string fields.",
    "category": "Backend",
    "tags": ["mongodb", "mongoose", "indexes"]
  }'
```

**201 Created**
```json
{
  "success": true,
  "data": {
    "_id": "665f1c2e8a1b2c3d4e5f6789",
    "title": "Mongoose Indexes",
    "content": "Text indexes allow MongoDB to perform efficient full-text search across string fields.",
    "category": "Backend",
    "tags": ["mongodb", "mongoose", "indexes"],
    "createdAt": "2026-06-17T10:00:00.000Z",
    "updatedAt": "2026-06-17T10:00:00.000Z"
  }
}
```

**400 Bad Request** (missing required field):
```json
{ "success": false, "message": "Title is required" }
```

---

### Get all notes (pagination, sorting, search, category filter)

`GET /api/notes`

| Query param | Description                                                       | Example              |
|-------------|--------------------------------------------------------------------|-----------------------|
| `page`      | Page number (default `1`)                                         | `?page=2`             |
| `limit`     | Results per page (default `10`)                                   | `?limit=5`             |
| `sort`      | Comma-separated fields; prefix with `-` for descending             | `?sort=-createdAt`     |
| `search` / `q` | Full-text search across `title` and `content`                  | `?search=mongodb`      |
| `category`  | Case-insensitive exact match on category                          | `?category=Backend`    |

**Basic list:**
```bash
curl http://localhost:5000/api/notes
```

**Pagination — page 2, 5 per page:**
```bash
curl "http://localhost:5000/api/notes?page=2&limit=5"
```

**Sorting — newest first:**
```bash
curl "http://localhost:5000/api/notes?sort=-createdAt"
```

**Sorting — alphabetical by title, then newest first as a tiebreaker:**
```bash
curl "http://localhost:5000/api/notes?sort=title,-createdAt"
```

**Full-text search (ranked by relevance):**
```bash
curl "http://localhost:5000/api/notes?search=mongodb"
```

**Filter by category:**
```bash
curl "http://localhost:5000/api/notes?category=Backend"
```

**Combine search, category filter, and pagination:**
```bash
curl "http://localhost:5000/api/notes?q=index&category=Backend&page=1&limit=10"
```

**200 OK**
```json
{
  "success": true,
  "count": 1,
  "pagination": {
    "total": 1,
    "page": 1,
    "limit": 10,
    "totalPages": 1,
    "hasNextPage": false,
    "hasPrevPage": false
  },
  "data": [
    {
      "_id": "665f1c2e8a1b2c3d4e5f6789",
      "title": "Mongoose Indexes",
      "content": "Text indexes allow MongoDB to perform efficient full-text search across string fields.",
      "category": "Backend",
      "tags": ["mongodb", "mongoose", "indexes"],
      "createdAt": "2026-06-17T10:00:00.000Z",
      "updatedAt": "2026-06-17T10:00:00.000Z"
    }
  ]
}
```

---

### Get a single note by ID

`GET /api/notes/:id`

```bash
curl http://localhost:5000/api/notes/665f1c2e8a1b2c3d4e5f6789
```

**404 Not Found** (valid ObjectId format, but no matching note):
```json
{ "success": false, "message": "Note not found with id: 665f1c2e8a1b2c3d4e5f6789" }
```

**400 Bad Request** (malformed ObjectId):
```bash
curl http://localhost:5000/api/notes/not-a-valid-id
```
```json
{ "success": false, "message": "Invalid ID format: not-a-valid-id" }
```

---

### Update a note

`PUT /api/notes/:id`

```bash
curl -X PUT http://localhost:5000/api/notes/665f1c2e8a1b2c3d4e5f6789 \
  -H "Content-Type: application/json" \
  -d '{ "category": "Databases", "tags": ["mongodb", "indexing"] }'
```

**200 OK**
```json
{
  "success": true,
  "data": {
    "_id": "665f1c2e8a1b2c3d4e5f6789",
    "title": "Mongoose Indexes",
    "content": "Text indexes allow MongoDB to perform efficient full-text search across string fields.",
    "category": "Databases",
    "tags": ["mongodb", "indexing"],
    "createdAt": "2026-06-17T10:00:00.000Z",
    "updatedAt": "2026-06-17T10:05:00.000Z"
  }
}
```

---

### Delete a note

`DELETE /api/notes/:id`

```bash
curl -X DELETE http://localhost:5000/api/notes/665f1c2e8a1b2c3d4e5f6789
```

**200 OK**
```json
{
  "success": true,
  "message": "Note deleted successfully",
  "data": { "_id": "665f1c2e8a1b2c3d4e5f6789", "...": "..." }
}
```

## Error Handling

| Status | Meaning                                                         |
|--------|-------------------------------------------------------------------|
| `200`  | Request succeeded                                                  |
| `201`  | Resource created successfully                                      |
| `400`  | Invalid input — failed validation, malformed ID, etc.               |
| `404`  | Resource (or route) not found                                       |
| `500`  | Unexpected server error                                             |

All errors funnel through a single global error-handling middleware (`middleware/errorHandler.js`), which normalizes Mongoose `CastError`, `ValidationError`, and duplicate-key errors into clean, consistent JSON responses.

## Testing with Postman

1. Import the base URL `http://localhost:5000/api/notes` as a Postman environment variable, e.g. `{{baseUrl}}`.
2. Create a collection with one request per endpoint above, using the same methods, paths, and example bodies/query params.
3. For quick smoke testing, create 3–4 notes with different categories and overlapping keywords in their content, then experiment with `search`, `category`, `sort`, and `page`/`limit` together.

## Tech Stack

- **Runtime:** Node.js + Express
- **Database:** MongoDB + Mongoose (with a weighted compound text index on `title`/`content`)
- **Validation:** Joi
- **Config:** dotenv
- **Dev tooling:** nodemon
