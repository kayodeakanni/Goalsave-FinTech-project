require('dotenv').config();

const express = require('express');
const connectDB = require('./config/db');
const noteRoutes = require('./routes/noteRoutes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

// Establish the MongoDB connection before the app starts accepting traffic
connectDB();

const app = express();

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Simple health-check / root route
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Personal Knowledge Base API is running',
  });
});

// Mount note routes
app.use('/api/notes', noteRoutes);

// 404 handler for unknown routes (must come after all valid routes)
app.use(notFound);

// Global error handler (must be the last middleware registered)
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
});

// Safety net: log and gracefully shut down on unhandled promise rejections
// (e.g. a DB error that wasn't caught) instead of leaving the process in a bad state.
process.on('unhandledRejection', (err) => {
  console.error(`Unhandled Rejection: ${err.message}`);
  server.close(() => process.exit(1));
});

module.exports = app;