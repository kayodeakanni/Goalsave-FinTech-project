const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    content: {
      type: String,
      required: [true, 'Content is required'],
      trim: true,
    },
    category: {
      type: String,
      trim: true,
      default: 'General',
    },
    tags: {
      type: [String],
      default: [],
      set: (tags) => (Array.isArray(tags) ? tags.map((tag) => String(tag).trim().toLowerCase()) : tags),
    },
  },
  {
    timestamps: true, // adds createdAt and updatedAt automatically
  }
);

// Compound text index enabling full-text search across title and content.
// Title matches are weighted more heavily than content matches in relevance scoring.
noteSchema.index(
  { title: 'text', content: 'text' },
  { weights: { title: 5, content: 1 }, name: 'NoteTextIndex' }
);

// Standard index to speed up category-based filtering
noteSchema.index({ category: 1 });

module.exports = mongoose.model('Note', noteSchema);